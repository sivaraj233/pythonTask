import React from "react";
import { connect } from 'react-redux'
import { useSelector } from 'react-redux'
import { CSVLink, CSVDownload } from "react-csv"
import { getBooks, getAuthor, createBooks, searchBooks } from '../Redux/actions.js'
import { Card, Row, Col, Table, message, Input, Slider, Button, Modal, Select, Upload } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { UploadOutlined } from '@ant-design/icons'
import "antd/dist/antd.css";


class ListBooks extends React.Component {

    async componentDidMount() {
        this.props.getBooks();
        this.props.getAuthor();
    }
    data = {
        name: "",
        book_price: 0,
        author: []
    }
    filter = {
        name: "",
        min_price: 0,
        max_price: 10000,

    }
    deletePost = (id) => {
        this.props.deletePost(id, this.info);
    }

    info() {
        message.info('Post Deleted');
    };
    state = { visible: false };

    showModal = () => {
        this.setState({
            visible: true,
        });
    };
    handleChange = (value) => {
        this.data.author.push(value)
    }
    handleOk = e => {
        this.props.createBooks(this.data)
        this.setState({
            visible: false,
        });
    };

    handleCancel = e => {
        this.setState({
            visible: false,
        });
    };
    searchBook = (e) => {
        this.filter.name = e
        this.props.searchBooks(this.filter)
    };
    rangeFilter = (e) => {
        console.log(e[0])
        this.filter.min_price = e[0]
        this.filter.max_price = e[1]
        this.props.searchBooks(this.filter)
    };
    editModal = (value) => {
        console.log('asdfasd')
        console.log(value)
    };
    render() {
        console.log(this.props)
        const results = this.props.posts
        const authorlist = this.props.authorlist.results
        const filterValue = results
        const pagination = this.props.posts.count
        const { Search } = Input;
        const { Option } = Select;
        const getRandomuserParams = params => {
            return {
                results: params.pagination.pageSize,
                page: params.pagination.current,
                ...params,
            };
        };
        const rowSelection = {
            results,
            onChange: this.onSelectChange,
            selections: [
                Table.SELECTION_ALL,
                Table.SELECTION_INVERT,
                {
                    key: 'odd',
                    text: 'Select Odd Row',
                    onSelect: changableRowKeys => {
                        let newSelectedRowKeys = [];
                        newSelectedRowKeys = changableRowKeys.filter((key, index) => {
                            if (index % 2 !== 0) {
                                return false;
                            }
                            return true;
                        });
                        this.setState({ selectedRowKeys: newSelectedRowKeys });
                    },
                },
                {
                    key: 'even',
                    text: 'Select Even Row',
                    onSelect: changableRowKeys => {
                        let newSelectedRowKeys = [];
                        newSelectedRowKeys = changableRowKeys.filter((key, index) => {
                            if (index % 2 !== 0) {
                                return true;
                            }
                            return false;
                        });
                        this.setState({ selectedRowKeys: newSelectedRowKeys });
                    },
                },
            ],
        };
        const uploadFile = {
            name: 'file',
            action: 'http://127.0.0.1:8000/api/books/',
            headers: {
              authorization: 'authorization-text',
            },
            onChange(info) {
              if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList);
              }
              if (info.file.status === 'done') {
                message.success(`${info.file.name} file uploaded successfully`);
              } else if (info.file.status === 'error') {
                message.error(`${info.file.name} file upload failed.`);
              }
            },
          };
        const columns = [
            {
                title: 'Book Name',
                dataIndex: 'name',
                key: 'name',
                filters: results,
                onFilter: (value, record) => record.name.indexOf(value) === 0,
                sorter: (a, b) => a.name.length - b.name.length,
                sortDirections: ['descend', 'ascend'],
            },
            {
                title: 'Book Price',
                dataIndex: 'book_price',
                key: 'book_price',
                filters: results,
                onFilter: (value, record) => record.book_price.indexOf(value) === 0,
                sorter: {
                    compare: (a, b) => a.book_price - b.book_price,
                    multiple: 2,
                },
                sortDirections: ['descend', 'ascend'],
            },
            {
                title: 'Author Name',
                dataIndex: 'author_name',
                key: 'author_name',
                filters: results,
                onFilter: (value, record) => record.author_name.indexOf(value) === 0,
                sorter: (a, b) => a.author_name.length - b.author_name.length,
                sortDirections: ['descend', 'ascend'],
            },
            {
                title: 'Create Date',
                dataIndex: 'created_at',
                key: 'created_at',
                filters: results,
                onFilter: (value, record) => record.author_name.indexOf(value) === 0,
                sorter: (a, b) => a.author_name.length - b.author_name.length,
                sortDirections: ['descend', 'ascend'],
            },
            {
                title: 'Published Date',
                dataIndex: 'published_at',
                key: 'published_at',
                filters: results,
                onFilter: (value, record) => record.author_name.indexOf(value) === 0,
                sorter: (a, b) => a.author_name.length - b.author_name.length,
                sortDirections: ['descend', 'ascend'],
            },
            {
                title: 'Edit',
                dataIndex: 'edit',
                key: 'edit',
                render: (text, record) => (<span>
                    <Button onClick={this.editModal} key={record}>Edit</Button>
                </span>)
            },
        ]
        const options = authorlist && authorlist.map(d => <Option key={d.id}>{d.name}</Option>);
        return (
            <div>
                <Row>
                    <Col span={8}>
                        <Search
                            placeholder="Search Book"
                            enterButton="Search"
                            size="large"
                            onSearch={this.searchBook} />
                    </Col>
                    <Col span={8}>
                        <Slider range marks={this.filter.min_price, this.filter.max_price} defaultValue={[26, 37]} onChange={this.rangeFilter} min={0} max={1000} />
                    </Col>
                    <Col span={8}>
                        <Button type="primary" icon={<DownloadOutlined />} onClick={this.showModal}> Add Book</Button>
                    </Col>
                </Row>
                <Table pagination={pagination}
                    dataSource={results} columns={columns} />
                <CSVLink filename={"bookshop.csv"} data={results} className="primary">
                    <Button type="primary" icon={<DownloadOutlined />}>Export</Button>
                </CSVLink>
                <Upload {...uploadFile}>
                    <Button icon={<UploadOutlined />}>Click to Upload</Button>
                </Upload>,
                <Modal
                    title="Add New Books"
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    okText="submit"
                    onCancel={this.handleCancel}
                >
                    <p>Book Name: </p> <Input name="bookname" onChange={value => this.data.name = value.target.value} />
                    <p>Book Price: </p><Input name="bookprice" onChange={value => this.data.book_price = value.target.value} />
                    <p>Author : </p>
                    <Select style={{ width: 120 }} onChange={this.handleChange}>
                        {options}
                    </Select>
                </Modal>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    posts: state.posts,
    authorlist: state.authorlist
})

const mapDispatchToProps = {
    getBooks, getAuthor, createBooks, searchBooks
}

export default connect(mapStateToProps, mapDispatchToProps)(ListBooks)