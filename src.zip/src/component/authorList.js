import React from "react";
import { connect } from 'react-redux'
import { useSelector } from 'react-redux'
import { getAuthor, searchAuthor, createAuthor } from '../Redux/actions.js'
import { Card, Row, Col, Table, message, Input, Slider, Button, Modal, Select } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { AudioOutlined } from '@ant-design/icons';
import "antd/dist/antd.css";


class AuthorList extends React.Component {
    data = {
        name: ''
    }
    componentDidMount() {
        this.props.getAuthor();
    }

    deletePost = (id) => {
        this.props.deletePost(id, this.info);
    }

    state = { visible: false };
    searchAuthors = (e) => {
        // this.filter.name = e
        this.props.searchAuthor(e)
    };
    handleOk = e => {
        this.props.createAuthor(this.data)
        this.setState({
            visible: false,
        });
    };

    handleCancel = e => {
        this.setState({
            visible: false,
        });
    };
    showModal = () => {
        this.setState({
            visible: true,
        });
    };
    render() {
        console.log(this.props)
        const authorlist = this.props.authorlist
        console.log(authorlist)
        const { Search } = Input;
        const rowSelection = {
            authorlist,
            onChange: this.onSelectChange,
            selections: [
                Table.SELECTION_ALL,
                Table.SELECTION_INVERT,
                {
                    key: 'odd',
                    text: 'Select Odd Row',
                    onSelect: changableRowKeys => {
                        let newSelectedRowKeys = [];
                        newSelectedRowKeys = changableRowKeys.filter((key, index) => {
                            if (index % 2 !== 0) {
                                return false;
                            }
                            return true;
                        });
                        this.setState({ selectedRowKeys: newSelectedRowKeys });
                    },
                },
                {
                    key: 'even',
                    text: 'Select Even Row',
                    onSelect: changableRowKeys => {
                        let newSelectedRowKeys = [];
                        newSelectedRowKeys = changableRowKeys.filter((key, index) => {
                            if (index % 2 !== 0) {
                                return true;
                            }
                            return false;
                        });
                        this.setState({ selectedRowKeys: newSelectedRowKeys });
                    },
                },
            ],
        };

        const columns = [
            {
                title: 'Author Name',
                dataIndex: 'name',
                key: 'name',
                filters: authorlist,
                onFilter: (value, record) => record.name.indexOf(value) === 0,
                sorter: (a, b) => a.name.length - b.name.length,
                sortDirections: ['descend', 'ascend'],
            },
        ]

        const suffix = (
            <AudioOutlined
                style={{
                    fontSize: 16,
                    color: '#1890ff',
                }}
            />
        );

        return (
            <div>
                <Search
                    placeholder="Search Author"
                    enterButton="Search"
                    size="large"
                    onSearch={this.searchAuthors}
                />
                <Col span={8}>
                    <Button type="primary" icon={<DownloadOutlined />} onClick={this.showModal}> Add Author</Button>
                </Col>
                <Table dataSource={authorlist} columns={columns} rowSelection={rowSelection} />
                <Modal
                    title="Add New Authors"
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    okText="submit"
                    onCancel={this.handleCancel}
                >
                    <p>Author Name: </p> <Input name="authorName" onChange={value => this.data.name = value.target.value} />
                </Modal>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    posts: state.posts,
    authorlist: state.authorlist
})

const mapDispatchToProps = {
    getAuthor, searchAuthor, createAuthor
}

export default connect(mapStateToProps, mapDispatchToProps)(AuthorList)