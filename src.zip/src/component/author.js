import React from "react";
import { Layout, Menu, Row } from 'antd';
import ListBooks from "./listBooks";
import AuthorList from "./authorList";


class Author extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selected: 1
        }
    }
    handleClick = e => {
        this.setState({ selected: e })
    }
    render() {
        const { Header, Content } = Layout;

        return (
            <Row>
                <Menu theme="dark" mode="inline" style={{ width: 256 }} defaultSelectedKeys={[this.state.selected.toString()]}>
                    <Menu.Item key="1" onClick={() => this.handleClick(1)}> Book List</Menu.Item>
                    <Menu.Item key="2" onClick={() => this.handleClick(2)}> Author List</Menu.Item>
                </Menu>
                <Content>
                {this.state.selected==1 ? <ListBooks />:<AuthorList />}
                </Content>
            </Row>
        );
    }
}


export default Author