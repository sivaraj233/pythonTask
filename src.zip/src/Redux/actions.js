import Types from "./types";
import axios from "axios";

export const getBooks = () => {
    return dispatch => {
        dispatch({ type: Types.POSTS_LOADING, payload: true })
        axios.get('http://127.0.0.1:8000/api/books/')
            .then(response => {
                dispatch({ type: Types.GET_POSTS, payload: response.data })
            }
            )
            .catch(err => {
                console.log(err)
                dispatch({ type: Types.POSTS_LOADING, payload: false })
            }
            );
    }
}

export const searchBooks = (data) => {
    return dispatch => {
        dispatch({ type: Types.POSTS_LOADING, payload: true })
        axios.get(`http://127.0.0.1:8000/api/books/?name=${data.name}&max_price=${data.max_price}&min_price=${data.min_price}`)
            .then(response => {
                dispatch({ type: Types.SEARCH_POST, payload: response.data })
            }
            )
            .catch(err => {
                console.log(err)
                dispatch({ type: Types.POSTS_LOADING, payload: false })
            }
            );
    }
}


export const getAuthor = () => {
    return dispatch => {
        dispatch({ type: Types.POSTS_LOADING, payload: true })
        axios.get('http://127.0.0.1:8000/api/author/')
            .then(response => {
                dispatch({ type: Types.GET_AUTHOR, payload: response.data })
            }
            )
            .catch(err => {
                console.log(err)
                dispatch({ type: Types.POSTS_LOADING, payload: false })
            }
            );
    }
}
export const searchAuthor = (data) => {
    return dispatch => {
        dispatch({ type: Types.POSTS_LOADING, payload: true })
        axios.get(`http://127.0.0.1:8000/api/author/?name=${data}`)
            .then(response => {
                dispatch({ type: Types.SEARCH_AUTHOR, payload: response.data })
            }
            )
            .catch(err => {
                console.log(err)
                dispatch({ type: Types.POSTS_LOADING, payload: false })
            }
            );
    }
}

export const deletePost = (id, cb) => {
    return dispatch => {
        dispatch({ type: Types.POSTS_LOADING, payload: true })
        axios.delete(`http://127.0.0.1:8000/api/author'/${id}/`)
            .then(response => {
                dispatch({ type: Types.DELETE_POST, payload: id });
                cb();
            }
            )
            .catch(err => {
                console.log(err)
            }
            );
    }
}


export const createBooks = (data,cb) => {
    return dispatch => {
        axios.post(`http://127.0.0.1:8000/api/books/`, data)
            .then(response => {
                console.log(response)
                    dispatch({type:Types.CREATE_POST, payload:response.data});
                    cb()
                }
            )
            .catch(err => {
                    console.log(err)
                    dispatch({type:Types.POSTS_LOADING, payload:false})
                }
            );
    }
}

export const createAuthor = (data,cb) => {
    return dispatch => {
        axios.post(`http://127.0.0.1:8000/api/author/`, data)
            .then(response => {
                console.log(response)
                    dispatch({type:Types.CREATE_AUTHOR, payload:response.data});
                    cb()
                }
            )
            .catch(err => {
                    console.log(err)
                    dispatch({type:Types.POSTS_LOADING, payload:false})
                }
            );
    }
}