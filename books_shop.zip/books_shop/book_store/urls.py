from django.urls import path
from . import views

urlpatterns = [
    path('books/', views.ListBooks.as_view(), name='books'),
    path('author/', views.AddAuthor.as_view(), name='add-author'),
    path('author/<int:pk>/', views.AuthorDetails.as_view(), name='add-author'),
    path('books/<int:pk>/', views.BookDetails.as_view(), name='add-author'),

]