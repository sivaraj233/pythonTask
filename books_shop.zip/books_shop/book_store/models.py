from django.db import models

# Create your models here.


class Author(models.Model):
    name = models.CharField(max_length=255, null=False, blank=False)
    objects = models.Manager()

    def __str__(self):
        return self.name


class Books(models.Model):
    name = models.CharField(max_length=255, null=False, blank=False)
    author = models.ManyToManyField(Author, null=False, blank=False, related_name='authors')
    book_price = models.IntegerField(default=0, blank=False)
    created_at = models.DateTimeField(auto_now_add=True)
    published_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()

    def __str__(self):
        return '{}'.format(self.name)