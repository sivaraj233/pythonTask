from django.core.exceptions import ObjectDoesNotExist
from django.http import Http404
from rest_framework.exceptions import ParseError
from rest_framework.generics import ListCreateAPIView
from rest_framework.parsers import FileUploadParser
from rest_framework.pagination import PageNumberPagination
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import generics, status
from django_filters import rest_framework as filters
from . import serializers
from . import models
from . import pagination


# Create your views here.
class StandardResultsSetPagination(PageNumberPagination):
    """
    A class to override page number pagination
    """
    page_size = 10
    page_size_query_param = 'page_size'
    max_page_size = 1000


class AddAuthor(ListCreateAPIView):
    serializer_class = serializers.AuthorSerializer
    queryset = models.Author.objects.all()
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_fields = ['name', ]

    def get(self, request, *args, **kwargs):
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "author is created", 'STATUS': status.HTTP_200_OK}, status=status.HTTP_200_OK)
        else:
            return Response({'message': 'author is not created', 'STATUS': status.HTTP_400_BAD_REQUEST},
                            status=status.HTTP_400_BAD_REQUEST)


class AuthorDetails(APIView):
    serializer_class = serializers.AuthorSerializer
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_fields = ['name', ]

    @staticmethod
    def get_object(pk):
        try:
            return models.Author.objects.get(id=pk)
        except ObjectDoesNotExist:
            raise Http404

    def get(self, request, **kwargs):
        pk = kwargs.get('pk')
        author = self.get_object(pk)
        serializer = self.serializer_class(author)
        return Response(serializer.data)

    def put(self, request, **kwargs):
        pk = kwargs.get('pk')
        author = self.get_object(pk)
        serializer = self.serializer_class(instance=author, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_202_ACCEPTED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, **kwargs):
        pk = kwargs.get('pk')
        author = self.get_object(pk)
        author.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class ListBooks(ListCreateAPIView):
    # pagination_class = StandardResultsSetPagination
    serializer_class = serializers.BookSerializer
    queryset = models.Books.objects.all()
    filter_backends = (filters.DjangoFilterBackend, )
    filterset_fields = ['name', 'created_at']

    def get(self, request, *args, **kwargs):
        min_price = request.GET.get('min_price')
        max_price = request.GET.get('max_price')
        try:
            self.queryset = self.queryset.filter(book_price__gte=min_price, book_price__lte=max_price)
        except:
            pass
        # self.pagination_class.page_size = int(request.GET.get('size', 10))
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_405_METHOD_NOT_ALLOWED)


class BookDetails(APIView):
    serializer_class = serializers.BookSerializer

    @staticmethod
    def get_object(pk):
        try:
            return models.Books.objects.get(id=pk)
        except ObjectDoesNotExist:
            raise Http404

    def get(self, request, **kwargs):
        pk = kwargs.get('pk')
        books = self.get_object(pk)
        serializer = self.serializer_class(books)
        return Response(serializer.data)

    def put(self, request, **kwargs):
        pk = kwargs.get('pk')
        books = self.get_object(pk)
        serializer = self.serializer_class(instance=books, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_202_ACCEPTED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, **kwargs):
        pk = kwargs.get('pk')
        books = self.get_object(pk)
        books.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

