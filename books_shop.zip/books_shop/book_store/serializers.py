from rest_framework import serializers
from . import models


class BookSerializer(serializers.ModelSerializer):

    author_name = serializers.SlugRelatedField(source='author', read_only=True, many=True, slug_field='name')

    class Meta:
        model = models.Books
        fields = '__all__'
        extra_kwargs = {'id': {'read_only': True},
                        'created_at': {'read_only': True},
                        }


class AuthorSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Author
        fields = '__all__'
        extra_kwargs = {'id': {'read_only': True},
                        'created_at': {'read_only': True},
                        }